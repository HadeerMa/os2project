/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osproject;

/**
 *
 * @author SMART
 */
public class Reader extends Thread {
       
      public Reader (String name){
         this.setName(name);
      }

   
    @Override
    public void run() {
        while(true){
        GUIFrame.c.startReading();
        GUIFrame.c.read();
        GUIFrame.c.stopReading();
        }
    }
     
}
