/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osproject;

import java.util.Random;

/**
 *
 * @author SMART
 */
public class Writer extends Thread{
   
     public Writer (String name){
     this.setName(name);
     }

  
    @Override
    public void run() {
       
        while(true){
           GUIFrame.c.startWrite();
           GUIFrame.c.Write("Random= "+ new Random().nextInt(20));
           GUIFrame.c.stopwriting();
        }
        
    }
    
}
