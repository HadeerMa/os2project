/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osproject;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SMART
 */
public class controller {
        boolean writing;
        int waitingWriters,readers;
        
        
        public synchronized void startWrite(){
         System.out.println(Thread.currentThread().getName()+"Request to write   ");
        while(writing || readers>0){
            try {
                waitingWriters++;
                System.out.println(Thread.currentThread().getName()+"wait   ");
                wait();
                waitingWriters--;
                System.out.println(Thread.currentThread().getName()+"notify   ");
            } catch (InterruptedException ex) {
                waitingWriters--;
                Logger.getLogger(controller.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
       writing = true;   
    }
    public  void Write (String s){
      System.out.println(Thread.currentThread().getName()+"start  Writing");
      GUIFrame.Text.setText(s);
      System.out.println(Thread.currentThread().getName()+"finish Writing");
    }
    public synchronized void stopwriting(){
       System.out.println(Thread.currentThread().getName()+"stop Writing   ");
       writing = false;
       
       notifyAll();
    }
    public synchronized void startReading(){
        System.out.println(Thread.currentThread().getName()+"Request to read   ");
       while(writing || waitingWriters>0){
           try {
               System.out.println(Thread.currentThread().getName()+"wait   ");
               wait();
               System.out.println(Thread.currentThread().getName()+"notify   ");
           } catch (InterruptedException ex) {
               Logger.getLogger(controller.class.getName()).log(Level.SEVERE, null, ex);
           }
          }
       readers++;
    }
    public void read(){
      System.out.println(Thread.currentThread().getName()+"start reading    ");
      System.out.println(Thread.currentThread().getName()+"Reading"+GUIFrame.Text.getText());
      System.out.println(Thread.currentThread().getName()+"Finish read   ");
    }
    public synchronized void stopReading(){
         System.out.println(Thread.currentThread().getName()+"stop reading   ");
       readers--;
      
       if(readers==0){
          notifyAll();
       }
       
    }
}
